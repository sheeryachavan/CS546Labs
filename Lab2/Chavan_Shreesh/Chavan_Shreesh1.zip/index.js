let l_objUtilities = require('./utilities.js');
let l_objGeometry = require('./geometry.js');

// =============================Geometry==============================
l_objGeometry.volumeOfRectangularPrism(10, 12, "10");// 1200
l_objGeometry.surfaceAreaOfRectangularPrism(10, 12, "10");//680
l_objGeometry.volumeOfSphere(10);//4188.790204786391
l_objGeometry.surfaceAreaOfSphere("10");//1256.6370614359173


// ==============================Utilities============================
const first = { a: 2, b: 3 };
const second = { a: 2, b: 4 };
const third = { a: 2, b: 3 };
console.log(l_objUtilities.deepEquality(first, second)); // false
console.log(l_objUtilities.deepEquality(first, third)); // true
console.log(l_objUtilities.deepEquality({
    "name": "John",
    "age": 30,
    "cars": {
        "car1": "Ford",
        "car2": "BMW",
        "car3": "Fiat"
    }
}, {
        "name": "John",
        "age": 30,
        "cars": { "car1": "Chrysler" }
    }));




const testArr = ["a", "a", "b", "a", "b", "c"];
console.log(l_objUtilities.uniqueElements(testArr)); // outputs 3

const test = "Hello, the pie is in the oven";
const charMap = l_objUtilities.countOfEachCharacterInString(test);
console.log(charMap);
